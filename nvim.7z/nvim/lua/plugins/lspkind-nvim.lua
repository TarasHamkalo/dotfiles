return {
	"onsails/lspkind-nvim",
	lazy = true,
	config = function()
		require("configs.lspkind-nvim")
	end,
}
